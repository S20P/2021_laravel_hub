
                                    <table class="table table-bordered mb-5">
                                        <thead>
                                            <tr class="table-success">
                                                <th scope="col">#</th>
                                                <th scope="col">Report</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php if($EvictionsData->count() == 0): ?>
                                            <tr>
                                                <td colspan="5">No Bankruptcy records to display.</td>
                                            </tr>
                                            <?php endif; ?>
                                            <?php $__currentLoopData = $EvictionsData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <th scope="row"><?php echo e($data->RqUID); ?></th>
                                                <td>
                                                 <button class="btn btn-primary GetArchiveReport" data-Report="Evictions" data-AppId="<?php echo e($data->response['MsgRsHdr']['RqUID'] ?? ''); ?>">GetArchiveReport</button> 
                                                    <p class="msg"></p> 
                                                    <div class="ArchiveReportPrview">
                                                         <h1>Archive Report Preview</h1>
                                                   
                                                    <?php
                                                    $response = $data->response;
                                                    ?>

                                                    <?php if(isset($response['Subject'])): ?>
                                                    <?php
                                                    $subject = $data->response['Subject'];
                                                    ?>
                                                    <?php $__currentLoopData = $subject; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subjectData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                                                   <P> <b>RecordID</b>: <?php echo e($subjectData['RecordID'] ?? ''); ?><br /> </P> 
                                                   <P> <b>EvictionsInd</b>: <?php echo e($subjectData['EvictionsInd'] ?? ''); ?><br /> </P> 

                                                    <table id="products-table" class="table table-bordered table-hover" class="display"
                                                        style="width:100%">
                                                        <thead>
                                                            <th>FileDate</th>
                                                            <th>CourtName</th>
                                                            <th>CountyCode</th>
                                                            <th>FilingState</th>
                                                            <th>AssetAmt</th>
                                                            <th>LiabilityAmt</th>
                                                        </thead>
                                                        <tbody>
                                                        <tr>
                                                            <td><?php echo e($subjectData['EvictionsCase']['FileDt'] ?? ''); ?></td>
                                                            <td><?php echo e($subjectData['EvictionsCase']['CourtName'] ?? ''); ?></td>
                                                            <td><?php echo e($subjectData['EvictionsCase']['CountyCode'] ?? ''); ?></td>
                                                            <td><?php echo e($subjectData['EvictionsCase']['FilingState'] ?? ''); ?></td>
                                                            <td><?php echo e($subjectData['EvictionsCase']['AssetAmt']['Amt'] ?? ''); ?> <?php echo e($subjectData['EvictionsCase']['AssetAmt']['CurCode'] ?? ''); ?> </td>
                                                            <td><?php echo e($subjectData['EvictionsCase']['LiabilityAmt']['Amt'] ?? ''); ?> <?php echo e($subjectData['EvictionsCase']['LiabilityAmt']['CurCode'] ?? ''); ?> </td>
                                                        </tr>
                                                        </tbody>
                                                    </table>
                                                    <!-- Parties -->
                                                    <?php if(isset($subjectData['Parties'])): ?>
                                                    <h3>Parties</h3>
                                                    <table id="products-table" class="table table-bordered table-hover" class="display"
                                                        style="width:100%">
                                                        <thead>
                                                            <th>PartyType</th>
                                                            <th>PersonInfo</th>
                                                            <th>ContactInfo</th>
                                                            <th>Source</th>
                                                            <th>EffDate</th>
                                                        </thead>
                                                        <tbody>
                                                            <?php $__currentLoopData = $subjectData['Parties']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Parties): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if(isset($Parties) && count($Parties)>0): ?>

                                                            <tr>
                                                                <td>
                                                                    <?php echo e($Parties['PartyType'] ?? ''); ?>

                                                                </td>
                                                                <td>
                                                                    <?php if(isset($Parties['PersonInfo']) && count($Parties['PersonInfo'])>0): ?>
                                                                    <?php $__currentLoopData = $Parties['PersonInfo']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $PersonInfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php $__currentLoopData = $PersonInfo['PersonName']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <b><?php echo e($key ?? ''); ?></b>: <?php echo e($value ?? ''); ?><br />
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php endif; ?>
                                                                </td>
                                                                <td>
                                                                    <?php if(isset($Parties['PersonInfo']) && count($Parties['PersonInfo'])>0): ?>
                                                                    <?php $__currentLoopData = $Parties['PersonInfo']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $PersonInfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php if(isset($PersonInfo['ContactInfo']) && count($PersonInfo['ContactInfo'])>0): ?>
                                                                    <?php $__currentLoopData = $PersonInfo['ContactInfo']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ContactInfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php $__currentLoopData = $ContactInfo['PostAddr']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <b><?php echo e($key ?? ''); ?></b>: <?php echo e($value ?? ''); ?><br />
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php endif; ?>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php endif; ?>
                                                                </td>
                                                                <td>
                                                                    <?php echo e($Parties['Source'] ?? ''); ?>

                                                                </td>
                                                                <td>
                                                                    <?php echo e($Parties['EffDt'] ?? ''); ?>

                                                                </td>
                                                            </tr>
                                                            <?php endif; ?>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </tbody>
                                                    </table>
                                                    <?php endif; ?>
                                                    <!-- Parties -->

                                                    <!-- FilingsInfo -->

                                                    <?php if(isset($subjectData['FilingsInfo'])): ?>

                                                    <h3>FilingsInfo</h3>

                                                    <table class="table table-bordered mb-5">
                                                        <thead>
                                                            <tr class="table-success">
                                                                <th scope="col">FilingType</th>
                                                                <th scope="col">FilingDate</th>
                                                                <th scope="col">ActionCode</th>
                                                                <th scope="col">Source</th>
                                                                <th scope="col">EffDate</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                        <?php $__currentLoopData = $subjectData['FilingsInfo']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $FilingsInfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <tr>
                                                                <th scope="row"><?php echo e($FilingsInfo['FilingType'] ?? ''); ?></th>
                                                                <td><?php echo e($FilingsInfo['FilingDt'] ?? ''); ?></td>
                                                                <td>
                                                                <?php $__currentLoopData = $FilingsInfo['ActionCode']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <b><?php echo e($key ?? ''); ?></b>: <?php echo e($value ?? ''); ?><br />
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </td>
                                                                <td><?php echo e($FilingsInfo['Source'] ?? ''); ?></td>
                                                                <td><?php echo e($FilingsInfo['EffDt'] ?? ''); ?></td>
                                                            </tr>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </tbody>
                                                    </table>
                                                    <?php endif; ?>
                                                    <!-- FilingsInfo -->

                                                    <!-- Message -->

                                                    <?php if(isset($subjectData['Message'])): ?>

                                                    <h3>Message</h3>

                                                    <table class="table table-bordered mb-5">
                                                        <thead>
                                                            <tr class="table-success">
                                                                <th scope="col">MsgClass</th>
                                                                <th scope="col">MsgCode</th>
                                                                <th scope="col">Text</th>
                                                                <th scope="col">Source</th>
                                                                <th scope="col">EffDate</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                        <?php $__currentLoopData = $subjectData['Message']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <tr>
                                                                <th scope="row"><?php echo e($Message['MsgClass'] ?? ''); ?></th>
                                                                <td><?php echo e($Message['MsgCode'] ?? ''); ?></td>
                                                                <td><?php echo e($Message['Text'] ?? ''); ?></td>
                                                                <td><?php echo e($Message['Source'] ?? ''); ?></td>
                                                                <td><?php echo e($Message['EffDt'] ?? ''); ?></td>
                                                            </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </tbody>
                                                    </table>
                                                    <?php endif; ?>
                                                    <!-- Message -->

                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endif; ?>
                                                    </div>
                                                </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>

                                    
                                    <div class="d-flex justify-content-center">
                                        <?php echo $EvictionsData->links(); ?>

                                    </div>

<?php /**PATH /opt/lampp/htdocs/Project/Laravel/Demo/microbilt-api/Microbilt-Developer-Api/resources/views/MicrobiltStore/EvictionsRecord.blade.php ENDPATH**/ ?>