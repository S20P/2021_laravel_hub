
<!doctype html>
<html>
<head>
    <?php echo $__env->make('MicrobiltStore.includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body>
<div class="container">

    <header class="row">
        <?php echo $__env->make('MicrobiltStore.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </header>

    <div id="main">
            <?php echo $__env->yieldContent('content'); ?>
    </div>

    <footer class="row">
        <?php echo $__env->make('MicrobiltStore.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </footer>
    <?php echo $__env->make('MicrobiltStore.includes.footerScripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
</body>
</html><?php /**PATH /opt/lampp/htdocs/Project/Laravel/Demo/microbilt-api/Microbilt-Developer-Api/resources/views/MicrobiltStore/layouts/default.blade.php ENDPATH**/ ?>