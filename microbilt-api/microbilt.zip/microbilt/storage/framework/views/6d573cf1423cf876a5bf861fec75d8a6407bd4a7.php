
                                    <table class="table table-bordered mb-5">
                                        <thead>
                                            <tr class="table-success">
                                                <th scope="col">#</th>
                                                <th scope="col">Report</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php if($BankruptcyData->count() == 0): ?>
                                            <tr>
                                                <td colspan="5">No Bankruptcy records to display.</td>
                                            </tr>
                                            <?php endif; ?>
                                            <?php $__currentLoopData = $BankruptcyData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <th scope="row"><?php echo e($data->RqUID); ?></th>
                                                <td>
                                                    <?php echo e($data->response['MsgRsHdr']['RqUID'] ?? ''); ?>


                                                    <?php
                                                    $response = $data->response;
                                                    ?>

                                                    <?php if(isset($response['Subject'])): ?>
                                                    <?php
                                                    $subject = $data->response['Subject'];
                                                    ?>
                                                    <?php $__currentLoopData = $subject; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subjectData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                    <!-- Parties -->

                                                    <?php if(isset($subjectData['Parties'])): ?>
                                                    <h3>Parties</h3>
                                                    <table id="products-table" class="table table-bordered table-hover" class="display"
                                                        style="width:100%">
                                                        <thead>
                                                            <th>RecordID</th>
                                                            <th>PartyType</th>
                                                            <th>OrgInfo</th>
                                                            <th>PersonInfo</th>
                                                            <th>ContactInfo</th>
                                                            <th>Source</th>
                                                            <th>EffDate</th>
                                                        </thead>
                                                        <tbody>
                                                            <?php $__currentLoopData = $subjectData['Parties']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Parties): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if(isset($Parties) && count($Parties)>0): ?>

                                                            <tr>
                                                                <td>
                                                                    <?php echo e($Parties['RecordID'] ?? ''); ?>

                                                                </td>
                                                                <td>
                                                                    <?php echo e($Parties['PartyType'] ?? ''); ?>

                                                                </td>
                                                                <td>
                                                                    <?php if(isset($Parties['OrgInfo']) && count($Parties['OrgInfo'])>0): ?>
                                                                    <?php $__currentLoopData = $Parties['OrgInfo']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $OrgInfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                     <P> <b>Name</b>: <?php echo e($OrgInfo['Name'] ?? ''); ?></P>
                                                                     <?php $__currentLoopData = $OrgInfo['ContactInfo']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ContactInfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                     <P> <b>PhoneType</b>: <?php echo e($ContactInfo['PhoneNum']['PhoneType'] ?? ''); ?></P>
                                                                     <P> <b>Phone</b>: <?php echo e($ContactInfo['PhoneNum']['Phone'] ?? ''); ?></P>
                                                                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                                     <P> <b>EmailAddr</b>: <?php echo e($ContactInfo['EmailAddr'] ?? ''); ?></P>
                                                                     <?php $__currentLoopData = $ContactInfo['PostAddr']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                     <P><b><?php echo e($key ?? ''); ?></b>: <?php echo e($value ?? ''); ?></P>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php endif; ?>
                                                                </td>
                                                                <td>
                                                                    <?php if(isset($Parties['PersonInfo']) && count($Parties['PersonInfo'])>0): ?>
                                                                    <?php $__currentLoopData = $Parties['PersonInfo']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $PersonInfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php $__currentLoopData = $PersonInfo['PersonName']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <b><?php echo e($key ?? ''); ?></b>: <?php echo e($value ?? ''); ?><br />
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php if(isset($PersonInfo['TINInfo'])): ?>
                                                                    <?php $__currentLoopData = $PersonInfo['TINInfo']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <b><?php echo e($key ?? ''); ?></b>: <?php echo e($value ?? ''); ?><br />
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php endif; ?>

                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php endif; ?>
                                                                </td>
                                                                <td>
                                                                    <?php if(isset($Parties['PersonInfo']) && count($Parties['PersonInfo'])>0): ?>
                                                                    <?php $__currentLoopData = $Parties['PersonInfo']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $PersonInfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php if(isset($PersonInfo['ContactInfo']) && count($PersonInfo['ContactInfo'])>0): ?>
                                                                    <?php $__currentLoopData = $PersonInfo['ContactInfo']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ContactInfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php $__currentLoopData = $ContactInfo['PostAddr']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <b><?php echo e($key ?? ''); ?></b>: <?php echo e($value ?? ''); ?><br />
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php endif; ?>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php endif; ?>
                                                                </td>
                                                                <td>
                                                                    <?php echo e($Parties['Source'] ?? ''); ?>

                                                                </td>
                                                                <td>
                                                                    <?php echo e($Parties['EffDt'] ?? ''); ?>

                                                                </td>
                                                            </tr>
                                                            <?php endif; ?>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </tbody>
                                                    </table>
                                                    <?php endif; ?>
                                                    <!-- Parties -->

                                                    <!-- PublicRecord -->

                                                    <?php if(isset($subjectData['PublicRecord'])): ?>

                                                    <h3>PublicRecord</h3>

                                                    <table class="table table-bordered mb-5">
                                                        <thead>
                                                            <tr class="table-success">
                                                                <th scope="col">CaseId</th>
                                                                <th scope="col">PRType</th>
                                                                <th scope="col">AttorneyName</th>
                                                                <th scope="col">Amt</th>
                                                                <th scope="col">CurCode</th>
                                                                <th scope="col">CourtName</th>
                                                                <th scope="col">FilingDt</th>
                                                                <th scope="col">DefendantName</th>
                                                                <th scope="col">Plaintiff</th>
                                                                <th scope="col">JudgeTrustee</th>
                                                                <th scope="col">DismissedDt</th>
                                                                <th scope="col">CourtInfo</th>
                                                                <th scope="col">ClosedDt</th>
                                                                <th scope="col">ReOpenedDt</th>
                                                                <th scope="col">ConvertedDt</th>
                                                                <th scope="col">TransferredDt</th>
                                                                <th scope="col">WithdrawnDt</th>
                                                                <th scope="col">ClaimDt</th>
                                                                <th scope="col">ObjectionDt</th>
                                                                <th scope="col">OrigCase</th>
                                                                <th scope="col">OrigBook</th>
                                                                <th scope="col">OrigPage</th>
                                                                <th scope="col">Sch341DtTime</th>
                                                                <th scope="col">OriginalAmt</th>
                                                                <th scope="col">ReleaseDt</th>
                                                                <th scope="col">AssetsAvailForUnsecuredInd</th>
                                                           </tr>
                                                        </thead>
                                                        <tbody>
                                                        <?php $__currentLoopData = $subjectData['PublicRecord']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $PublicRecord): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <tr>
                                                                <th scope="row"><?php echo e($PublicRecord['CaseId'] ?? ''); ?></th>
                                                                <td><?php echo e($PublicRecord['PRType'] ?? ''); ?></td>
                                                                <td><?php echo e($PublicRecord['AttorneyName'] ?? ''); ?></td>
                                                                <td><?php echo e($PublicRecord['BankruptcyAssetsAmt']['Amt'] ?? ''); ?></td>
                                                                <td><?php echo e($PublicRecord['BankruptcyAssetsAmt']['CurCode'] ?? ''); ?></td>
                                                                <td><?php echo e($PublicRecord['CourtName'] ?? ''); ?></td>
                                                                <td><?php echo e($PublicRecord['FilingDt'] ?? ''); ?></td>
                                                                <td><?php echo e($PublicRecord['DefendantName'] ?? ''); ?></td>
                                                                <td><?php echo e($PublicRecord['Plaintiff'] ?? ''); ?></td>
                                                                <td><?php echo e($PublicRecord['JudgeTrustee'] ?? ''); ?></td>
                                                                <td><?php echo e($PublicRecord['DismissedDt'] ?? ''); ?></td>
                                                                <td>
                                                                <?php $__currentLoopData = $PublicRecord['CourtInfo']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $CourtInfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <p><b>CourtState</b>: <?php echo e($CourtInfo['CourtState'] ?? ''); ?> </p>
                                                                    <p><b>BookPage</b>: <?php echo e($CourtInfo['BookPage'] ?? ''); ?> </p>
                                                                    <p><b>CourtJurisdiction</b>: <?php echo e($CourtInfo['CourtJurisdiction'] ?? ''); ?> </p>
                                                                    <p><b>CourtName</b>: <?php echo e($CourtInfo['CourtName'] ?? ''); ?> </p>
                                                                    <p><b>CourtCaseId</b>: <?php echo e($CourtInfo['CourtCaseId'] ?? ''); ?> </p>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                   
                                                                </td>
                                                                <td><?php echo e($PublicRecord['ClosedDt'] ?? ''); ?></td>
                                                                <td><?php echo e($PublicRecord['ReOpenedDt'] ?? ''); ?></td>
                                                                <td><?php echo e($PublicRecord['ConvertedDt'] ?? ''); ?></td>
                                                                <td><?php echo e($PublicRecord['TransferredDt'] ?? ''); ?></td>
                                                                <td><?php echo e($PublicRecord['WithdrawnDt'] ?? ''); ?></td>
                                                                <td><?php echo e($PublicRecord['ClaimDt'] ?? ''); ?></td>
                                                                <td><?php echo e($PublicRecord['ObjectionDt'] ?? ''); ?></td>
                                                                <td><?php echo e($PublicRecord['OrigCase'] ?? ''); ?></td>
                                                                <td><?php echo e($PublicRecord['OrigBook'] ?? ''); ?></td>
                                                                <td><?php echo e($PublicRecord['OrigPage'] ?? ''); ?></td>
                                                                <td><?php echo e($PublicRecord['Sch341DtTime'] ?? ''); ?></td>
                                                                <td><?php echo e($PublicRecord['OriginalAmt']['Amt'] ?? ''); ?>  <?php echo e($PublicRecord['OriginalAmt']['CurCode']); ?></td>
                                                                <td><?php echo e($PublicRecord['ReleaseDt'] ?? ''); ?></td>
                                                                <td><?php echo e($PublicRecord['AssetsAvailForUnsecuredInd'] ?? ''); ?></td>
                                                            </tr>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </tbody>
                                                    </table>
                                                    <?php endif; ?>
                                                    <!-- PublicRecord -->

                                                    <!-- Message -->

                                                    <?php if(isset($subjectData['Message'])): ?>

                                                    <h3>Message</h3>

                                                    <table class="table table-bordered mb-5">
                                                        <thead>
                                                            <tr class="table-success">
                                                                <th scope="col">MsgClass</th>
                                                                <th scope="col">MsgCode</th>
                                                                <th scope="col">Text</th>
                                                                <th scope="col">Source</th>
                                                                <th scope="col">EffDate</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                        <?php $__currentLoopData = $subjectData['Message']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <tr>
                                                                <th scope="row"><?php echo e($Message['MsgClass'] ?? ''); ?></th>
                                                                <td><?php echo e($Message['MsgCode'] ?? ''); ?></td>
                                                                <td><?php echo e($Message['Text'] ?? ''); ?></td>
                                                                <td><?php echo e($Message['Source'] ?? ''); ?></td>
                                                                <td><?php echo e($Message['EffDt'] ?? ''); ?></td>
                                                            </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </tbody>
                                                    </table>
                                                    <?php endif; ?>
                                                    <!-- Message -->

                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>

                                    
                                    <div class="d-flex justify-content-center">
                                        <?php echo $BankruptcyData->links(); ?>

                                    </div>
                        <?php /**PATH /opt/lampp/htdocs/Project/Laravel/Demo/microbilt-api/Microbilt-Developer-Api/resources/views/MicrobiltStore/BankruptcyRecord.blade.php ENDPATH**/ ?>