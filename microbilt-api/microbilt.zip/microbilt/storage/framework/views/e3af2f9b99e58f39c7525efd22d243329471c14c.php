<meta charset="utf-8">
<meta name="description" content="">
<meta name="author" content="Scotch">
<meta name="_token" content="<?php echo e(csrf_token()); ?>" />
<title>Microbilt APIs</title>

<!-- load bootstrap from a cdn -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

<link rel="stylesheet" href=
    "https://maxcdn.bootstrapcdn.com/bootstrap/
     4.0.0/css/bootstrap.min.css">
    <!-- jQuery library -->
 

<link rel="stylesheet" href="<?php echo e(asset('css/custom.css')); ?>">
<?php /**PATH /opt/lampp/htdocs/Project/Laravel/Demo/microbilt-api/Microbilt-Developer-Api/resources/views/MicrobiltStore/includes/head.blade.php ENDPATH**/ ?>