
    <table class="table table-bordered mb-5">
        <thead>
            <tr class="table-success">
                <th scope="col">#</th>
                <th scope="col">Report</th>
            </tr>
        </thead>
        <tbody>
            <?php if($CriminalData->count() == 0): ?>
            <tr>
                <td colspan="5">No Bankruptcy records to display.</td>
            </tr>
            <?php endif; ?>
            <?php $__currentLoopData = $CriminalData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th scope="row"><?php echo e($data->RqUID); ?></th>
                <td>
              
                    <button class="btn btn-primary GetArchiveReport" data-Report="Evictions" data-AppId="<?php echo e($data->response['MsgRsHdr']['RqUID'] ?? ''); ?>">GetArchiveReport</button> 
                                                    <p class="msg"></p> 
                                                    <div class="ArchiveReportPrview">
                                                         <h1>Archive Report Preview</h1>
                    <?php
                    $response = $data->response;
                    ?>

                    <?php if(isset($response['Subject'])): ?>
                    <?php
                    $subject = $data->response['Subject'];
                    ?>

                    <table id="products-table" class="table table-bordered table-hover" class="display"
                        style="width:100%">
                        <thead>
                            <th>DataSource</th>
                            <th>RecordID</th>
                            <th>RecordType</th>
                            <th >PersonInfo</th>
                            <th>CriminalInfo</th>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $subject; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subjectData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <tr>
                                <td>
                                    <?php echo e($subjectData['DataSource'] ?? ''); ?>

                                </td>
                                <td>
                                    <?php echo e($subjectData['RecordID'] ?? ''); ?>

                                </td>
                                <td>
                                    <?php echo e($subjectData['RecordType'] ?? ''); ?>

                                </td>
                                <td>
                                    <?php if(isset($subjectData['PersonInfo']) && count($subjectData['PersonInfo'])>0): ?>
                                    <h4>PersonName</h4>
                                    <?php if(isset($subjectData['PersonInfo']['PersonName']['FirstName'])): ?>
                                    <p> <b>FirstName</b>:    <?php echo e($subjectData['PersonInfo']['PersonName']['FirstName'] ?? ''); ?> </p>
                                    <?php endif; ?>

                                    <?php if(isset($subjectData['PersonInfo']['PersonName']['LastName'])): ?>
                                    <p> <b>LastName</b>:    <?php echo e($subjectData['PersonInfo']['PersonName']['LastName'] ?? ''); ?> </p>
                                    <?php endif; ?>

                                    <?php if(isset($subjectData['PersonInfo']['PersonName']['MiddleName'])): ?>
                                    <p> <b>MiddleName</b>:    <?php echo e($subjectData['PersonInfo']['PersonName']['MiddleName'] ?? ''); ?> </p>
                                    <?php endif; ?>
                                   
                                   <h4>ContactInfo</h4>
                                    <?php if(isset($subjectData['PersonInfo']['ContactInfo']) && count($subjectData['PersonInfo']['ContactInfo'])>0): ?>
                                    <?php $__currentLoopData = $subjectData['PersonInfo']['ContactInfo']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ContactInfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $__currentLoopData = $ContactInfo['PostAddr']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                   <p> <b><?php echo e($key ?? ''); ?></b>: <?php echo e($value ?? ''); ?> </p>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                    <?php if(isset($subjectData['PersonInfo']['BirthDt'])): ?>
                                    <p> <b>Birth Date</b>:    <?php echo e($subjectData['PersonInfo']['BirthDt'] ?? ''); ?> </p>
                                    <?php endif; ?>
                                    <?php if(isset($subjectData['PersonInfo']['PhysicalCharacteristics'])): ?>
                                    <h4>PhysicalCharacteristics</h4>
                                     <?php $__currentLoopData = $subjectData['PersonInfo']['PhysicalCharacteristics']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <p>  <b><?php echo e($key ?? ''); ?></b>: <?php echo e($value ?? ''); ?></p>
                                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                    <?php if(isset($subjectData['PersonInfo']['MilitaryIdInfo']['MilitaryIdNum'])): ?>
                                    <p> <b>MilitaryIdNum</b>:    <?php echo e($subjectData['PersonInfo']['MilitaryIdInfo']['MilitaryIdNum'] ?? ''); ?> </p>
                                    <?php endif; ?>
                                
                                    <?php endif; ?>
                                   </td>
                                <td>
                                    <?php if(isset($subjectData['CriminalCase'])): ?>

                                     <?php

                                     $CriminalCase = $subjectData['CriminalCase'];

                                     ?> 

                                     <table id="products-table" class="table table-bordered table-hover" class="display"
                                        style="width:100%">
                                        <thead>
                                            <th>CaseId</th>
                                            <th>ArrestingAgency</th>
                                            <th>CourtName</th>
                                            <th>CourtJurisdiction</th>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td><?php echo e($CriminalCase['CaseId'] ?? ''); ?></td>
                                                <td>
                                                    <?php if(isset($CriminalCase['ArrestingAgency']) && count($CriminalCase['ArrestingAgency'])>0): ?>
                                                    <?php $__currentLoopData = $CriminalCase['ArrestingAgency']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <b><?php echo e($key ?? ''); ?></b>: <?php echo e($value ?? ''); ?><br />
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endif; ?>
                                                </td>
                                                <td><?php echo e($CriminalCase['CourtName'] ?? ''); ?></td>
                                                <td><?php echo e($CriminalCase['CourtJurisdiction'] ?? ''); ?></td>
                                             </tr>
                                         </tbody>
                                     </table>

                                     <?php if(isset($CriminalCase['Charge']) && count($CriminalCase['Charge'])>0): ?>
                                     <h4>Charge Info</h4>
                                                   <table id="products-table" class="table table-bordered table-hover"
                                                        class="display" style="width:100%">
                                                        <thead>
                                                            <th>ChargeDt</th>
                                                            <th>OffenseDt</th>
                                                            <th>DispositionDt</th>
                                                            <th>OriginationState</th>
                                                            <th>OffenseDesc</th>
                                                            <th>Statute</th>
                                                            <th>OriginationName</th>
                                                            <th>CaseType</th>
                                                            <th>Source</th>
                                                            <th>EffDt</th>
                                                        </thead>
                                                        <tbody>
                                                            <?php $__currentLoopData = $CriminalCase['Charge']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Charge): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                </tr>
                                                                <td><?php echo e($Charge['ChargeDt'] ?? ''); ?></td>
                                                                <td><?php echo e($Charge['OffenseDt'] ?? ''); ?></td>
                                                                <td><?php echo e($Charge['DispositionDt'] ?? ''); ?></td>
                                                                <td><?php echo e($Charge['OriginationState'] ?? ''); ?></td>
                                                                <td><?php echo e($Charge['OffenseDesc'] ?? ''); ?></td>
                                                                <td><?php echo e($Charge['Statute'] ?? ''); ?></td>
                                                                <td><?php echo e($Charge['OriginationName'] ?? ''); ?></td>
                                                                <td><?php echo e($Charge['CaseType'] ?? ''); ?></td>
                                                                <td><?php echo e($Charge['Source'] ?? ''); ?></td>
                                                                <td><?php echo e($Charge['EffDt'] ?? ''); ?></td>
                                                                </tr>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </tbody>
                                                    </table>
                                                    <?php endif; ?>
                                            <?php endif; ?>
                                        </td>
  
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
    </table>
    <?php endif; ?>
    </div>
    </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
    </table>

    
    <div class="d-flex justify-content-center">
        <?php echo $CriminalData->links(); ?>

    </div>
<?php /**PATH /opt/lampp/htdocs/Project/Laravel/Demo/microbilt-api/Microbilt-Developer-Api/resources/views/MicrobiltStore/CriminalRecord.blade.php ENDPATH**/ ?>