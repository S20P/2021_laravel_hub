<?php $__env->startSection('content'); ?>
   


<div class="container register-form top-buffer-1">

<?php if(session()->has('error')): ?>
    <div class="alert alert-danger">
        <?php echo e(session()->get('error')); ?>

    </div>
<?php endif; ?>

<?php if(session()->has('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session()->get('success')); ?>

    </div>
<?php endif; ?>

		  <div class="form">
			  <div class="note">
				<p>MicroBilt APIs </p>
			  </div>
		    <div class="form-content bk">
				<form action="<?php echo e(route('microbilt.BankruptcyGetReportSave')); ?>" method="POST" id="BankruptcyForm" class="BankruptcyForm">
				<?php echo csrf_field(); ?>	

        <fieldset class="scheduler-border">
        <legend class="scheduler-border">API</legend>
           <div class="col-sm-12">
              <label for="phone">Select API Search Type</label>
							  <select class="form-control" name="api_type" id="api_type">
								<option value="Bankruptcy" selected>Bankruptcy Search</option>
								<option value="Evictions">Evictions, Suits, Liens & Judgments</option>
								<option value="Criminal">Criminal Records Search</option>
							  </select>
							</div>
					</fieldset>

             <fieldset class="scheduler-border">
						<legend class="scheduler-border">Person Information</legend>
						<div class="row">
                            <div class="col-sm-8">
							  <label for="LastName">Last Name</label>
							  <input type="text" class="form-control" id="LastName" placeholder="Last Name" name="LastName">
							</div>
							<div class="col-sm-8">
							  <label for="FirstName">First Name</label>
							  <input type="text" class="form-control" id="FirstName" placeholder="First Name" name="FirstName">
							</div>
							
                <div class="col-sm-8">
							  <label for="MiddleName">Middle Name</label>
							  <input type="text" class="form-control" id="MiddleName" placeholder="Middle Name" name="MiddleName">
							</div>

              <div class="col-sm-8" id="BirthDt_section">
							  <label for="yop">Birth Date</label>
							  <input name="BirthDt" class="form-control" id="BirthDt" type="date" />
							</div>

						</div>
					</fieldset>
					<!-- Contact Information -->
					<fieldset class="scheduler-border">
						<legend class="scheduler-border">Contact Information</legend>
                        <div class="row top-buffer">
							<!-- Address -->
							  <div class="form-group col-sm-3">
								<label for="inputAddress">Address</label>
								<input type="text" class="form-control" id="Addr1" name="Addr1" placeholder="Address">
							  </div>
							  <div class="form-row">
								<div class="form-group col-sm-2">
								  <label for="inputCity">City</label>
								  <input type="text" class="form-control" name="City" id="City" placeholder="City">
								</div>
								<div class="form-group col-sm-2">
								  <label for="inputState">StateProv</label>
								  <input type="text" class="form-control" name="StateProv" id="StateProv" placeholder="StateProv">
								</div>
								<div class="form-group col-md-2">
								  <label for="inputZip">PostalCode</label>
								  <input type="text" class="form-control" name="PostalCode" id="PostalCode" placeholder="PostalCode">
								</div>
							  </div>
							  <!-- Address -->
						</div>
					</fieldset>
					<!--Contact Information -->
				
					<!-- TINI Information-->
					<fieldset class="scheduler-border" id="TINInfo_section">
						<legend class="scheduler-border">TINI Information</legend>
                        <div class="row">
							<div class="col-sm-6">
							  <label for="fname">TINType</label>
							  <input type="text" class="form-control" id="TINType" placeholder="TIN Type" name="TINType">
							</div>
							<div class="col-sm-6">
							  <label for="lname">TaxId</label>
							  <input type="text" class="form-control" id="TaxId" placeholder="TaxId" name="TaxId">
							</div>
						</div>
					</fieldset>
					<!-- TINI Information -->

                   
					<button type="submit" class="btn btn-success" value="submit"> GetReport </button>
				</form>
			</div>
		  </div>
		  </div>

<?php $__env->startPush('scripts'); ?>
    
  <script>

//   jQuery Form Validation code 
$(function() {


  $("#BirthDt_section").hide();
  $("#TINInfo_section").show();

  
  $("#api_type").click(function(e){
    e.preventDefault();
    
     var api_type = $(this).val();

     console.log("api_type",api_type);
     
      if(api_type=="Criminal"){
         $("#BirthDt_section").show();
      }else{
         $("#BirthDt_section").hide();
      }

      if(api_type!=="Bankruptcy"){
         $("#TINInfo_section").hide();
      }else{
          $("#TINInfo_section").show();
      }
    

  // $('#BankruptcyForm').submit();
});
   
  $("#BankruptcyForm").validate({
    rules: {
        LastName : {
        required: true,
       },
       FirstName: {
        required: true,
      },
      MiddleName: {
        required: true,
      },
      Addr1: {
        required: true,
      },
      City: {
        required: true,
      },
      StateProv: {
        required: true,
      },
      PostalCode: {
        required: true,
      },
    },
    messages : {
        LastName: {
        required: "Please enter your LastName",
      },
      FirstName: {
        required: "Please enter your FirstName",
      },
      MiddleName: {
        required: "Please enter your MiddleName",
      },
      Addr1: {
        required: "Please enter your Addr1",
      },
      City: {
        required: "Please enter your City",
      },
      StateProv: {
        required: "Please enter your StateProv",
      },
      PostalCode: {
        required: "Please enter your PostalCode",
      },
    },
    submitHandler: function(form) {

       console.log("FORM",form.submit);
            form.submit();
    }
  });

  });

</script>
<?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>




<?php echo $__env->make('MicrobiltStore.layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/Project/Laravel/Demo/microbilt-api/Microbilt-Developer-Api/resources/views/MicrobiltStore/BankruptcySearchCreate.blade.php ENDPATH**/ ?>